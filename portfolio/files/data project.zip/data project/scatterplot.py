'''
3.2.7
Names: Kelly Pang and Sabrina Nguyen
Date: 2/5/2017

'''
import os.path
import matplotlib.pyplot as plt  
from scipy import stats as lr
import numpy as np

def create_scatterplot():
    # Open directory and open the csv file to collect the poverty and GDP data
    directory = os.path.dirname(os.path.abspath(__file__)) 
    filename = os.path.join(directory, 'usa_data.csv')
    datafile = open(filename,'r')  
    data = datafile.readlines()
    
    # Create lists to collect x and y data values
    rgdp = []
    poverty = []
    
    # Go through all the rows and columns in the csv file to extract the RGDP Growth and corresponding Poverty Percentage in that year 
    # Appends those values to 2 lists
    for line in data[1:]:
         # Split the line into the three separate pieces of info
        year, rgdp_growth, poverty_percentage  = line.split(',')
        rgdp.append(float(rgdp_growth))
        poverty.append(float(poverty_percentage))
    
    # Plot on one set of axes.
    fig, ax = plt.subplots(1,1)
    ax.scatter(rgdp, poverty, s=10, alpha=1, color = 'blue')
    ax.plot(rgdp, np.poly1d(np.polyfit(rgdp, poverty,1))(rgdp), color = "red") # Draw a line-of-best-fit on the scatterplot
    ax.set_xlabel('RGDP (US$)') 
    ax.set_ylabel('American Below 125% of the Poverty Level (Percent)')
    ax.set_title('Poverty vs. RGDP in the United States (between 1961-2015)')
    fig.patch.set_facecolor('cyan')
    fig.show()

    # Calculate the r-value to analyze the association between the two variables
    slope, intercept, r_value, p_value, std_err = lr.linregress(rgdp,poverty)
    print(r_value)
    print('The r-value indicates that there is a negative weak association between RGDP and the number of people in poverty in the United States')
    
    
create_scatterplot()